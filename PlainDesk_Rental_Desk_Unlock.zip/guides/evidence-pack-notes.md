# Evidence-pack notes (quick)

1. Use handover ProcessRunner photo slots — you take and file the photos.
2. Keep snag tickets linked to contractor WhatsApp / email you store.
3. Deposit close: calc → Approve deductions → Approve release — humans only.
4. Export JSON before Tribunal/attorney handoff if you need a books snapshot.
5. Not legal advice — verify against your lease and applicable law.
