# Rental Desk — unlock pack

**Faceless Plain Desk** · soft-launch unlock (suggested **R179**)

Free live demo (sample data): https://esteprinsloo101-web.github.io/rental-desk/

## What’s in this zip
- `app/` — full offline installable PWA
- `SETUP.md` — open locally, install, cases, backup
- `DISCLAIMER.md` — legal fence (read before use)
- `sample/sample-import.json` — demo sample for Import practice
- `guides/evidence-pack-notes.md` — short tip sheet

## Soft shop note
Stokvel pack https://stofficial.gumroad.com/l/ydbgne remains the primary public CTA until first ZAR. Garage Desk is never sellable.
